# 9-Tipps: #9 background-image for Text

A Pen created on CodePen.io. Original URL: [https://codepen.io/enbee81/pen/WNdKLBY](https://codepen.io/enbee81/pen/WNdKLBY).

